import React from 'react'

// Web App URL ของ Google Apps Script
const GAS_URL = "https://script.google.com/a/macros/parichat.skru.ac.th/s/AKfycbzQQgkRFNWvAip89LlVuJfcrCAM9lSBXaJkwldXJJklPe2GkrkOctawe0Q7x2xrL1q7/exec";

export default function App() {
  return (
    <div style={{ width: '100vw', height: '100vh', margin: 0, padding: 0, overflow: 'hidden' }}>
      <iframe 
        src={GAS_URL} 
        style={{ width: '100%', height: '100%', border: 'none' }}
        title="ระบบเรียกคิวเอกซเรย์ออนไลน์"
      />
    </div>
  )
}